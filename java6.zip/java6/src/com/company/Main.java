package com.company;
import com.company.controllermenu.ControllerLibraryMenu;

public class Main {

    public static void main(String[] args) {
            ControllerLibraryMenu menu=new ControllerLibraryMenu();
            menu.ManageMenu();
    }

}
