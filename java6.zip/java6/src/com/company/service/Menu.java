package com.company.service;

public class Menu {
}
